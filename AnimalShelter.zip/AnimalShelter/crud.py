# Name: Timothy Johnson
# Date: 1/29/2025
# CS 340 Module 4
# Professor Iles

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33489
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """ Insert a document into the MongoDB collection. """
        if data:
            try:
                insert_result = self.collection.insert_one(data)
                return True if insert_result.inserted_id else False
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, search_data):
        """ Query documents from the MongoDB collection based on search data """
        try:
            result = list(self.collection.find(search_data, {"_id": False}))
            return result
        except Exception as e:
            print(f"Read failed: {e}")
            return []
    
    def update(self, search_data, update_data):
        """ Update document(s) in the MongoDB collection based on search criteria. """
        if not update_data or not update_data:
            raise ValueError("Search and update date must be provided.")
            
        try:
            update_result = self.collection.update_many(search_data,{'$set':update_data})
            return update_result.modified_count
        except Exception as e:
            print(f"Update failed:{e}")
            return 0
            
    def delete(self,search_data):
        """ Delete document(s) from the MongoDB collection based on search criteria. """
        if not search_data:
            raise ValueError("Search data must be provided to delete records.")
            
        try:
            delete_result = self.collection.delete_many(search_data)
            return delete_result.deleted_count
        except Exception as e:
            print(f"Delete failed:{e}")
            return 0
        
               
               